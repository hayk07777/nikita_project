import styles from "./MainPart.module.scss";
import pause from "../../../images/picture/pause.png";

import firstGirl from "../../../images/picture/girl1.png";
import { NavigationPanel } from "../../HeaderPart/NavPanel/NavigationPanel";
import { HeaderAddPart } from "../../HeaderPart/HeaderAdd/HeaderAddPart";
export const MainPart = () => {
  return (
    <header>
      <HeaderAddPart />
      <NavigationPanel className={styles.nav}/>
      <div className={styles.container}>
        <div className={styles.textContainer}>
          <h1>Խելացի մտքեր, Ձեր բրենդնի համար💡</h1>
          <p>
            Բարձրացրեք ձեր վաճառքների ճանապարհը՝ արդյունավետ հաղորդակցությամբ
            յուրաքանչյուր քայլում։
          </p>
          <div className={styles.headerBtn}>
            <button>Կապ մեզ հետ </button>
            <div className={styles.pause}>
              <img src={pause} alt="pause" />
            </div>
          </div>
        </div>
        <div className={styles.imgCont}>
          <img src={firstGirl} alt="firstGirl" className={styles.girl} />
        </div>
      </div>
    </header>
  );
};
